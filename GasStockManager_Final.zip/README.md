# Gas Stock Manager

Android Kotlin + Jetpack Compose app for gas stock management.

Features:
- 17 products
- 6 vehicles
- Store Full and Empty stock
- Purchase Entry
- Vehicle Dispatch
- Vehicle Return
- Current Stock
- Transaction Reports
- Data saved locally on the phone

Build:
- JDK 17
- Java/JVM target 17
- Android SDK 35

GitHub Actions builds the debug APK automatically.
