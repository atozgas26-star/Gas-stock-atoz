package com.example.gasstock

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Product(var name: String, var full: Int = 0, var empty: Int = 0)
private data class Vehicle(val name: String, var full: Int = 0, var empty: Int = 0)
private data class Tx(
    val type: String,
    val product: String,
    val vehicle: String,
    val full: Int,
    val empty: Int,
    val time: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GasStockApp(this) }
    }
}

@Composable
private fun GasStockApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("gas_stock", Context.MODE_PRIVATE) }
    val defaultNames = remember { (1..17).map { "Product %02d".format(it) } }

    val products = remember {
        mutableStateListOf<Product>().also { list ->
            list.addAll(loadProducts(prefs, defaultNames))
        }
    }
    val vehicles = remember {
        mutableStateListOf<Vehicle>().also { list ->
            list.addAll(loadVehicles(prefs))
        }
    }
    val history = remember {
        mutableStateListOf<Tx>().also { it.addAll(loadTx(prefs)) }
    }

    var tab by remember { mutableStateOf("Dashboard") }
    var productIndex by remember { mutableIntStateOf(0) }
    var vehicleIndex by remember { mutableIntStateOf(0) }
    var qtyFull by remember { mutableStateOf("") }
    var qtyEmpty by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    fun saveAll() {
        saveProducts(prefs, products)
        saveVehicles(prefs, vehicles)
        saveTx(prefs, history)
    }

    fun quantity(value: String): Int = value.toIntOrNull()?.coerceAtLeast(0) ?: 0

    fun addTransaction(type: String, full: Int, empty: Int) {
        history.add(
            0,
            Tx(
                type = type,
                product = products[productIndex].name,
                vehicle = vehicles.getOrNull(vehicleIndex)?.name ?: "Store",
                full = full,
                empty = empty,
                time = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
            )
        )
        saveAll()
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("Gas Stock Manager") })
            },
            bottomBar = {
                NavigationBar {
                    listOf(
                        "Dashboard", "Products", "Purchase",
                        "Dispatch", "Return", "Stock", "Reports"
                    ).forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {},
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(14.dp)
                    .fillMaxSize()
            ) {
                if (message.isNotEmpty()) {
                    Text(message)
                    Spacer(Modifier.height(8.dp))
                }

                when (tab) {
                    "Dashboard" -> Dashboard(products, vehicles)

                    "Products" -> Products(products) { index, name ->
                        val clean = name.trim()
                        if (clean.isNotEmpty()) {
                            products[index].name = clean
                            saveAll()
                            message = "Product name saved"
                        }
                    }

                    "Purchase" -> Entry(
                        title = "Purchase Entry",
                        products = products,
                        vehicles = vehicles,
                        productIndex = productIndex,
                        vehicleIndex = vehicleIndex,
                        fullText = qtyFull,
                        emptyText = qtyEmpty,
                        showVehicle = false,
                        buttonText = "Add Purchase",
                        onProduct = { productIndex = it },
                        onVehicle = { vehicleIndex = it },
                        onFull = { qtyFull = it },
                        onEmpty = { qtyEmpty = it }
                    ) {
                        val full = quantity(qtyFull)
                        val empty = quantity(qtyEmpty)

                        if (full + empty == 0) {
                            message = "Enter a quantity"
                        } else {
                            products[productIndex].full += full
                            products[productIndex].empty += empty
                            addTransaction("PURCHASE", full, empty)
                            message = "Purchase saved"
                            qtyFull = ""
                            qtyEmpty = ""
                        }
                    }

                    "Dispatch" -> Entry(
                        title = "Vehicle Dispatch",
                        products = products,
                        vehicles = vehicles,
                        productIndex = productIndex,
                        vehicleIndex = vehicleIndex,
                        fullText = qtyFull,
                        emptyText = qtyEmpty,
                        showVehicle = true,
                        buttonText = "Dispatch",
                        onProduct = { productIndex = it },
                        onVehicle = { vehicleIndex = it },
                        onFull = { qtyFull = it },
                        onEmpty = { qtyEmpty = it }
                    ) {
                        val full = quantity(qtyFull)
                        val empty = quantity(qtyEmpty)

                        when {
                            full > products[productIndex].full ||
                                empty > products[productIndex].empty ->
                                message = "Not enough store stock"

                            full + empty == 0 ->
                                message = "Enter a quantity"

                            else -> {
                                products[productIndex].full -= full
                                products[productIndex].empty -= empty
                                vehicles[vehicleIndex].full += full
                                vehicles[vehicleIndex].empty += empty
                                addTransaction("DISPATCH", full, empty)
                                message = "Dispatched to ${vehicles[vehicleIndex].name}"
                                qtyFull = ""
                                qtyEmpty = ""
                            }
                        }
                    }

                    "Return" -> Entry(
                        title = "Vehicle Return",
                        products = products,
                        vehicles = vehicles,
                        productIndex = productIndex,
                        vehicleIndex = vehicleIndex,
                        fullText = qtyFull,
                        emptyText = qtyEmpty,
                        showVehicle = true,
                        buttonText = "Return to Store",
                        onProduct = { productIndex = it },
                        onVehicle = { vehicleIndex = it },
                        onFull = { qtyFull = it },
                        onEmpty = { qtyEmpty = it }
                    ) {
                        val full = quantity(qtyFull)
                        val empty = quantity(qtyEmpty)

                        when {
                            full > vehicles[vehicleIndex].full ||
                                empty > vehicles[vehicleIndex].empty ->
                                message = "Not enough vehicle stock"

                            full + empty == 0 ->
                                message = "Enter a quantity"

                            else -> {
                                vehicles[vehicleIndex].full -= full
                                vehicles[vehicleIndex].empty -= empty
                                products[productIndex].full += full
                                products[productIndex].empty += empty
                                addTransaction("RETURN", full, empty)
                                message = "Return saved from ${vehicles[vehicleIndex].name}"
                                qtyFull = ""
                                qtyEmpty = ""
                            }
                        }
                    }

                    "Stock" -> Stock(products, vehicles)
                    "Reports" -> Reports(history)
                }
            }
        }
    }
}

@Composable
private fun Dashboard(ps: List<Product>, vs: List<Vehicle>) {
    val storeFull = ps.sumOf { it.full }
    val storeEmpty = ps.sumOf { it.empty }
    val vehicleFull = vs.sumOf { it.full }
    val vehicleEmpty = vs.sumOf { it.empty }

    Text("Dashboard", style = MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(12.dp))

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Card(Modifier.weight(1f)) {
            Column(Modifier.padding(12.dp)) {
                Text("Store Full")
                Text("$storeFull", style = MaterialTheme.typography.headlineSmall)
            }
        }
        Card(Modifier.weight(1f)) {
            Column(Modifier.padding(12.dp)) {
                Text("Store Empty")
                Text("$storeEmpty", style = MaterialTheme.typography.headlineSmall)
            }
        }
    }

    Spacer(Modifier.height(14.dp))
    Text("Vehicle Totals", style = MaterialTheme.typography.titleLarge)
    Text("Full: $vehicleFull   Empty: $vehicleEmpty")

    LazyColumn {
        items(vs) {
            Text(
                "${it.name}: Full ${it.full} | Empty ${it.empty}",
                Modifier.padding(vertical = 7.dp)
            )
        }
    }
}

@Composable
private fun Products(
    ps: List<Product>,
    onSave: (Int, String) -> Unit
) {
    Text("Products (17)", style = MaterialTheme.typography.headlineMedium)

    LazyColumn {
        items(ps.indices.toList()) { index ->
            var name by remember(ps[index].name) {
                mutableStateOf(ps[index].name)
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    modifier = Modifier.weight(1f),
                    label = { Text("Product") }
                )
                Button(onClick = { onSave(index, name) }) {
                    Text("Save")
                }
            }

            Text("Full: ${ps[index].full}   Empty: ${ps[index].empty}")
        }
    }
}

@Composable
private fun Entry(
    title: String,
    products: List<Product>,
    vehicles: List<Vehicle>,
    productIndex: Int,
    vehicleIndex: Int,
    fullText: String,
    emptyText: String,
    showVehicle: Boolean,
    buttonText: String,
    onProduct: (Int) -> Unit,
    onVehicle: (Int) -> Unit,
    onFull: (String) -> Unit,
    onEmpty: (String) -> Unit,
    onSave: () -> Unit
) {
    Text(title, style = MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(8.dp))

    Text("Product: ${products[productIndex].name}")
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button({
            onProduct((productIndex + products.size - 1) % products.size)
        }) { Text("Prev") }

        Button({
            onProduct((productIndex + 1) % products.size)
        }) { Text("Next") }
    }

    if (showVehicle) {
        Spacer(Modifier.height(8.dp))
        Text("Vehicle: ${vehicles[vehicleIndex].name}")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button({
                onVehicle((vehicleIndex + vehicles.size - 1) % vehicles.size)
            }) { Text("Prev") }

            Button({
                onVehicle((vehicleIndex + 1) % vehicles.size)
            }) { Text("Next") }
        }
    }

    Spacer(Modifier.height(8.dp))

    OutlinedTextField(
        value = fullText,
        onValueChange = onFull,
        label = { Text("Full Quantity") },
        singleLine = true
    )

    Spacer(Modifier.height(6.dp))

    OutlinedTextField(
        value = emptyText,
        onValueChange = onEmpty,
        label = { Text("Empty Quantity") },
        singleLine = true
    )

    Spacer(Modifier.height(8.dp))

    Button(
        onClick = onSave,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(buttonText)
    }
}

@Composable
private fun Stock(ps: List<Product>, vs: List<Vehicle>) {
    Text("Current Stock", style = MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(8.dp))

    Text("STORE", style = MaterialTheme.typography.titleLarge)

    LazyColumn {
        items(ps) {
            Text(
                "${it.name} — Full: ${it.full}, Empty: ${it.empty}",
                Modifier.padding(5.dp)
            )
        }
    }

    Spacer(Modifier.height(8.dp))
    Text("VEHICLES", style = MaterialTheme.typography.titleLarge)

    vs.forEach {
        Text(
            "${it.name} — Full: ${it.full}, Empty: ${it.empty}",
            Modifier.padding(5.dp)
        )
    }
}

@Composable
private fun Reports(history: List<Tx>) {
    Text(
        "Reports / Transaction History",
        style = MaterialTheme.typography.headlineMedium
    )
    Spacer(Modifier.height(8.dp))

    if (history.isEmpty()) {
        Text("No transactions yet.")
    } else {
        LazyColumn {
            items(history) {
                Text(
                    "${it.time}  ${it.type}\n" +
                        "${it.product} | ${it.vehicle}\n" +
                        "Full: ${it.full}  Empty: ${it.empty}",
                    Modifier.padding(vertical = 8.dp)
                )
                HorizontalDivider()
            }
        }
    }
}

private fun loadProducts(
    prefs: android.content.SharedPreferences,
    names: List<String>
): List<Product> {
    return try {
        val array = JSONArray(prefs.getString("products", "[]"))
        List(names.size) { index ->
            val obj = array.optJSONObject(index)
            Product(
                name = obj?.optString("name", names[index]) ?: names[index],
                full = obj?.optInt("full", 0) ?: 0,
                empty = obj?.optInt("empty", 0) ?: 0
            )
        }
    } catch (_: Exception) {
        names.map { Product(it) }
    }
}

private fun saveProducts(
    prefs: android.content.SharedPreferences,
    products: List<Product>
) {
    val array = JSONArray()
    products.forEach {
        array.put(
            JSONObject()
                .put("name", it.name)
                .put("full", it.full)
                .put("empty", it.empty)
        )
    }
    prefs.edit().putString("products", array.toString()).apply()
}

private fun loadVehicles(
    prefs: android.content.SharedPreferences
): List<Vehicle> {
    return try {
        val array = JSONArray(prefs.getString("vehicles", "[]"))
        List(6) { index ->
            val obj = array.optJSONObject(index)
            Vehicle(
                name = "Vehicle ${index + 1}",
                full = obj?.optInt("full", 0) ?: 0,
                empty = obj?.optInt("empty", 0) ?: 0
            )
        }
    } catch (_: Exception) {
        (1..6).map { Vehicle("Vehicle $it") }
    }
}

private fun saveVehicles(
    prefs: android.content.SharedPreferences,
    vehicles: List<Vehicle>
) {
    val array = JSONArray()
    vehicles.forEach {
        array.put(
            JSONObject()
                .put("name", it.name)
                .put("full", it.full)
                .put("empty", it.empty)
        )
    }
    prefs.edit().putString("vehicles", array.toString()).apply()
}

private fun loadTx(
    prefs: android.content.SharedPreferences
): List<Tx> {
    return try {
        val array = JSONArray(prefs.getString("tx", "[]"))
        List(array.length()) { index ->
            val obj = array.getJSONObject(index)
            Tx(
                type = obj.getString("type"),
                product = obj.getString("product"),
                vehicle = obj.getString("vehicle"),
                full = obj.getInt("full"),
                empty = obj.getInt("empty"),
                time = obj.getString("time")
            )
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun saveTx(
    prefs: android.content.SharedPreferences,
    history: List<Tx>
) {
    val array = JSONArray()
    history.forEach {
        array.put(
            JSONObject()
                .put("type", it.type)
                .put("product", it.product)
                .put("vehicle", it.vehicle)
                .put("full", it.full)
                .put("empty", it.empty)
                .put("time", it.time)
        )
    }
    prefs.edit().putString("tx", array.toString()).apply()
}
