# Gas Stock Manager

Fresh Android project for a single-user gas stock store.

Features:
- 17 products
- 6 vehicles
- Store Full / Empty stock
- Purchase Entry
- Vehicle Dispatch
- Vehicle Return
- Current Stock
- Transaction Reports
- Local persistence with SharedPreferences

## GitHub build

Upload the contents of this folder to a GitHub repository, then open:
Actions -> Android Build -> Run workflow

The workflow builds the APK directly from the repository. It does not depend on a ZIP filename.
