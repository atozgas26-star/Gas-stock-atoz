package com.example.gasstock

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private data class Product(var name: String, var full: Int = 0, var empty: Int = 0)
private data class Vehicle(val name: String, var full: Int = 0, var empty: Int = 0)
private data class Tx(val type: String, val product: String, val vehicle: String, val full: Int, val empty: Int, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { GasStockApp(this) } }
}

@Composable
private fun GasStockApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("gas_stock", Context.MODE_PRIVATE) }
    val defaultNames = remember { (1..17).map { "Product %02d".format(it) } }
    val products = remember { mutableStateListOf<Product>().also { list -> loadProducts(prefs, defaultNames).forEach { list.add(it) } } }
    val vehicles = remember { mutableStateListOf<Vehicle>().also { list -> loadVehicles(prefs).forEach { list.add(it) } } }
    val history = remember { mutableStateListOf<Tx>().also { it.addAll(loadTx(prefs)) } }
    var tab by remember { mutableStateOf("Dashboard") }
    var p by remember { mutableIntStateOf(0) }
    var v by remember { mutableIntStateOf(0) }
    var qtyFull by remember { mutableStateOf("") }
    var qtyEmpty by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }

    fun saveAll() { saveProducts(prefs, products); saveVehicles(prefs, vehicles); saveTx(prefs, history) }
    fun q(s: String) = s.toIntOrNull()?.coerceAtLeast(0) ?: 0
    fun addTx(type: String, full: Int, empty: Int) { history.add(0, Tx(type, products[p].name, vehicles.getOrNull(v)?.name ?: "Store", full, empty, java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date()))); saveAll() }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Gas Stock Manager") }) }, bottomBar = {
            NavigationBar { listOf("Dashboard","Products","Purchase","Dispatch","Return","Stock","Reports").forEach { x -> NavigationBarItem(tab == x, { tab = x }, icon = {}, label = { Text(x) }) } }
        }) { pad ->
            Column(Modifier.padding(pad).padding(14.dp).fillMaxSize()) {
                if (msg.isNotEmpty()) { Text(msg); Spacer(Modifier.height(8.dp)) }
                when (tab) {
                    "Dashboard" -> Dashboard(products, vehicles)
                    "Products" -> Products(products) { i, name -> products[i].name = name; saveAll(); msg = "Product name saved" }
                    "Purchase" -> Entry("Purchase Entry", products, vehicles, p, v, qtyFull, qtyEmpty, false, "Add Purchase", { p=it }, {v=it}, {qtyFull=it}, {qtyEmpty=it}) {
                        val f=q(qtyFull); val e=q(qtyEmpty); if(f+e==0){msg="Enter a quantity"}else{products[p].full+=f; products[p].empty+=e; addTx("PURCHASE",f,e); msg="Purchase saved";qtyFull="";qtyEmpty=""}
                    }
                    "Dispatch" -> Entry("Vehicle Dispatch", products, vehicles, p, v, qtyFull, qtyEmpty, true, "Dispatch", {p=it},{v=it},{qtyFull=it},{qtyEmpty=it}) {
                        val f=q(qtyFull); val e=q(qtyEmpty); if(f>products[p].full||e>products[p].empty) msg="Not enough store stock" else if(f+e==0) msg="Enter a quantity" else {products[p].full-=f;products[p].empty-=e;vehicles[v].full+=f;vehicles[v].empty+=e;addTx("DISPATCH",f,e);msg="Dispatched to ${vehicles[v].name}";qtyFull="";qtyEmpty=""}
                    }
                    "Return" -> Entry("Vehicle Return", products, vehicles, p, v, qtyFull, qtyEmpty, true, "Return to Store", {p=it},{v=it},{qtyFull=it},{qtyEmpty=it}) {
                        val f=q(qtyFull); val e=q(qtyEmpty); if(f>vehicles[v].full||e>vehicles[v].empty) msg="Not enough vehicle stock" else if(f+e==0) msg="Enter a quantity" else {vehicles[v].full-=f;vehicles[v].empty-=e;products[p].full+=f;products[p].empty+=e;addTx("RETURN",f,e);msg="Return saved from ${vehicles[v].name}";qtyFull="";qtyEmpty=""}
                    }
                    "Stock" -> Stock(products, vehicles)
                    "Reports" -> Reports(history)
                }
            }
        }
    }
}

@Composable private fun Dashboard(ps: List<Product>, vs: List<Vehicle>) { val sf=ps.sumOf{it.full}; val se=ps.sumOf{it.empty}; val vf=vs.sumOf{it.full}; val ve=vs.sumOf{it.empty}; Text("Dashboard", style=MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Card(Modifier.weight(1f)){Column(Modifier.padding(12.dp)){Text("Store Full");Text("$sf",style=MaterialTheme.typography.headlineSmall)}};Card(Modifier.weight(1f)){Column(Modifier.padding(12.dp)){Text("Store Empty");Text("$se",style=MaterialTheme.typography.headlineSmall)}}}; Spacer(Modifier.height(14.dp));Text("Vehicle Totals",style=MaterialTheme.typography.titleLarge);LazyColumn{items(vs){Text("${it.name}: Full ${it.full} | Empty ${it.empty}",Modifier.padding(vertical=7.dp))}} }

@Composable private fun Products(ps: List<Product>, onSave:(Int,String)->Unit){Text("Products (17)",style=MaterialTheme.typography.headlineMedium);LazyColumn{items(ps.indices.toList()){i->var name by remember(ps[i].name){mutableStateOf(ps[i].name)};Row(Modifier.fillMaxWidth().padding(vertical=5.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(name,{name=it},Modifier.weight(1f),label={Text("Product")});Button({onSave(i,name)}){Text("Save")}};Text("Full: ${ps[i].full}   Empty: ${ps[i].empty}")}}}

@Composable private fun Entry(title:String,ps:List<Product>,vs:List<Vehicle>,p:Int,v:Int,f:String,e:String,showVehicle:Boolean,button:String,onP:(Int)->Unit,onV:(Int)->Unit,onF:(String)->Unit,onE:(String)->Unit,onSave:()->Unit){Text(title,style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(8.dp));Text("Product: ${ps[p].name}");Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button({onP((p+ps.size-1)%ps.size)}){Text("Prev")};Button({onP((p+1)%ps.size)}){Text("Next")}};if(showVehicle){Text("Vehicle: ${vs[v].name}");Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button({onV((v+vs.size-1)%vs.size)}){Text("Prev")};Button({onV((v+1)%vs.size)}){Text("Next")}}};OutlinedTextField(f,onF,label={Text("Full Quantity")});OutlinedTextField(e,onE,label={Text("Empty Quantity")});Spacer(Modifier.height(8.dp));Button(onSave,Modifier.fillMaxWidth()){Text(button)}}

@Composable private fun Stock(ps:List<Product>,vs:List<Vehicle>){Text("Current Stock",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(8.dp));Text("STORE",style=MaterialTheme.typography.titleLarge);LazyColumn{items(ps){Text("${it.name} — Full: ${it.full}, Empty: ${it.empty}",Modifier.padding(5.dp))}};Spacer(Modifier.height(8.dp));Text("VEHICLES",style=MaterialTheme.typography.titleLarge);vs.forEach{Text("${it.name} — Full: ${it.full}, Empty: ${it.empty}",Modifier.padding(5.dp))}}
@Composable private fun Reports(h:List<Tx>){Text("Reports / Transaction History",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(8.dp));if(h.isEmpty())Text("No transactions yet.") else LazyColumn{items(h){Text("${it.time}  ${it.type}\n${it.product} | ${it.vehicle}\nFull: ${it.full}  Empty: ${it.empty}",Modifier.padding(vertical=8.dp));HorizontalDivider()}}}

private fun loadProducts(p:android.content.SharedPreferences,names:List<String>):List<Product>{return try{val a=JSONArray(p.getString("products","[]"));List(names.size){i->val o=a.optJSONObject(i);Product(o?.optString("name",names[i])?:names[i],o?.optInt("full",0)?:0,o?.optInt("empty",0)?:0)}}catch(_:Exception){names.map{Product(it)}}}
private fun saveProducts(p:android.content.SharedPreferences,x:List<Product>){val a=JSONArray();x.forEach{a.put(JSONObject().put("name",it.name).put("full",it.full).put("empty",it.empty))};p.edit().putString("products",a.toString()).apply()}
private fun loadVehicles(p:android.content.SharedPreferences):List<Vehicle>{return try{val a=JSONArray(p.getString("vehicles","[]"));List(6){i->val o=a.optJSONObject(i);Vehicle("Vehicle ${i+1}",o?.optInt("full",0)?:0,o?.optInt("empty",0)?:0)}}catch(_:Exception){(1..6).map{Vehicle("Vehicle $it")}}}
private fun saveVehicles(p:android.content.SharedPreferences,x:List<Vehicle>){val a=JSONArray();x.forEach{a.put(JSONObject().put("name",it.name).put("full",it.full).put("empty",it.empty))};p.edit().putString("vehicles",a.toString()).apply()}
private fun loadTx(p:android.content.SharedPreferences):List<Tx>{return try{val a=JSONArray(p.getString("tx","[]"));List(a.length()){i->val o=a.getJSONObject(i);Tx(o.getString("type"),o.getString("product"),o.getString("vehicle"),o.getInt("full"),o.getInt("empty"),o.getString("time"))}}catch(_:Exception){emptyList()}}
private fun saveTx(p:android.content.SharedPreferences,x:List<Tx>){val a=JSONArray();x.forEach{a.put(JSONObject().put("type",it.type).put("product",it.product).put("vehicle",it.vehicle).put("full",it.full).put("empty",it.empty).put("time",it.time))};p.edit().putString("tx",a.toString()).apply()}
