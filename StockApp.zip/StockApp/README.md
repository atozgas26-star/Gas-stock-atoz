# Stock Manager (Kotlin + Jetpack Compose)

An offline-first stock tracking app for a business that moves **full** and
**empty** units (e.g. cylinders, crates, bottles) between a store and a
fleet of delivery vehicles.

Preloaded with **17 products** and **6 vehicles** (placeholder names —
rename them once the app is running; nothing else breaks since stock is
keyed by database id, not by name).

## Domain model / how the numbers move

| Screen | What it does |
|---|---|
| **Store Full / Empty** | Read-only view of what's physically sitting in the store right now, per product. |
| **Purchase** | Full stock arrives (e.g. from a supplier) → added to the store. |
| **Dispatch** | Full stock leaves the store and is loaded onto a vehicle for delivery. |
| **Vehicle Return** | A vehicle comes back: empties collected from customers, and/or unsold full units, move from the vehicle back into the store. |
| **Current Stock** | Tabs for the store and each vehicle, showing live full/empty counts per product. |
| **Reports** | Full history of every purchase/dispatch/return, filterable by type, plus running totals. |
| **Manage** | Rename products and vehicles in place (accessible from the Home grid). |

Every action above is written to an append-only `transactions` table, so
Reports is always a complete, replayable audit trail — nothing is ever
edited or deleted, only added to.

## Tech stack

- **Kotlin + Jetpack Compose** (Material 3) for UI
- **Room** for the offline SQLite database — no network calls anywhere
- **Simple MVVM** — one `AppViewModel` exposing `StateFlow`s, no Hilt/DI
  framework (per your preference); dependencies are wired by hand in
  `StockApplication` and passed through `AppViewModelFactory`
- **Navigation Compose** for screen routing (single-activity app)

## Project layout

```
app/src/main/java/com/example/stockapp/
  data/
    entities/         Product, Vehicle, StoreStock, VehicleStock, TransactionEntity
    dao/               Room DAOs for each entity
    AppDatabase.kt     Room database (version 1)
    AppRepository.kt   Business logic: recordPurchase / recordDispatch / recordVehicleReturn
    SeedData.kt        The 17 product names + 6 vehicle names loaded on first run
  viewmodel/
    AppViewModel.kt        Exposes StateFlows + user actions
    AppViewModelFactory.kt Manual DI (no Hilt)
  ui/
    navigation/Screen.kt   Route definitions
    screens/               One file per screen (see table above), plus HomeScreen
    components/            Shared ScreenScaffold (back button) + DropdownSelector
    theme/                 Material 3 theme
  MainActivity.kt          NavHost wiring
  StockApplication.kt      Creates the DB/repository, seeds data on first launch
```

## Opening the project

1. Open the `StockApp` folder in Android Studio (Koala/Ladybug or newer).
2. Let Gradle sync — it will download the Android Gradle Plugin, Kotlin,
   Compose, Room, and Navigation dependencies listed in
   `app/build.gradle.kts`.
3. Run on an emulator or device (minSdk 24 / Android 7.0+).

No `gradlew` wrapper files are included — Android Studio will offer to
generate one on first open (**File → Sync**, or it prompts automatically).

## Known simplification / things you'll likely want to customize

- Products and vehicles start with placeholder names (`Product 1`...
  `Vehicle 6`); rename them from the **Manage** screen after first launch —
  renaming never breaks stock history, since everything is keyed by id.
- No login/auth, no multi-user sync — this is a single-device, fully
  offline app as requested.
- No delete/undo for a transaction — by design, since Reports is meant to
  be an immutable audit log. If you need corrections, the simplest
  approach is a reversing transaction (e.g. a negative-adjustment
  purchase) rather than editing history.
- No launcher icon customization — uses the system default.
