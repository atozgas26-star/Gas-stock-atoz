package com.example.stockapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.stockapp.ui.navigation.Screen
import com.example.stockapp.ui.screens.CurrentStockScreen
import com.example.stockapp.ui.screens.DispatchScreen
import com.example.stockapp.ui.screens.HomeScreen
import com.example.stockapp.ui.screens.ManageScreen
import com.example.stockapp.ui.screens.PurchaseScreen
import com.example.stockapp.ui.screens.ReportsScreen
import com.example.stockapp.ui.screens.StoreStockScreen
import com.example.stockapp.ui.screens.VehicleReturnScreen
import com.example.stockapp.ui.theme.StockAppTheme
import com.example.stockapp.viewmodel.AppViewModel
import com.example.stockapp.viewmodel.AppViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as StockApplication

        setContent {
            StockAppTheme {
                val navController = rememberNavController()
                val viewModel: AppViewModel = viewModel(factory = AppViewModelFactory(app.repository))

                NavHost(navController = navController, startDestination = Screen.Home.route) {
                    composable(Screen.Home.route) { HomeScreen(navController) }
                    composable(Screen.StoreStock.route) { StoreStockScreen(navController, viewModel) }
                    composable(Screen.Purchase.route) { PurchaseScreen(navController, viewModel) }
                    composable(Screen.Dispatch.route) { DispatchScreen(navController, viewModel) }
                    composable(Screen.VehicleReturn.route) { VehicleReturnScreen(navController, viewModel) }
                    composable(Screen.CurrentStock.route) { CurrentStockScreen(navController, viewModel) }
                    composable(Screen.Reports.route) { ReportsScreen(navController, viewModel) }
                    composable(Screen.Manage.route) { ManageScreen(navController, viewModel) }
                }
            }
        }
    }
}
