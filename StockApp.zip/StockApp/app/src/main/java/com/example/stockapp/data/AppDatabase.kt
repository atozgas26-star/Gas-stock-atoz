package com.example.stockapp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.stockapp.data.dao.ProductDao
import com.example.stockapp.data.dao.StoreStockDao
import com.example.stockapp.data.dao.TransactionDao
import com.example.stockapp.data.dao.VehicleDao
import com.example.stockapp.data.dao.VehicleStockDao
import com.example.stockapp.data.entities.Product
import com.example.stockapp.data.entities.StoreStock
import com.example.stockapp.data.entities.TransactionEntity
import com.example.stockapp.data.entities.Vehicle
import com.example.stockapp.data.entities.VehicleStock

@Database(
    entities = [Product::class, Vehicle::class, StoreStock::class, VehicleStock::class, TransactionEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun vehicleDao(): VehicleDao
    abstract fun storeStockDao(): StoreStockDao
    abstract fun vehicleStockDao(): VehicleStockDao
    abstract fun transactionDao(): TransactionDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "stock_app.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
