package com.example.stockapp.data

import androidx.room.withTransaction
import com.example.stockapp.data.entities.Product
import com.example.stockapp.data.entities.StoreStock
import com.example.stockapp.data.entities.TransactionEntity
import com.example.stockapp.data.entities.TransactionType
import com.example.stockapp.data.entities.Vehicle
import com.example.stockapp.data.entities.VehicleStock
import kotlinx.coroutines.flow.Flow

class AppRepository(private val db: AppDatabase) {

    private val productDao = db.productDao()
    private val vehicleDao = db.vehicleDao()
    private val storeStockDao = db.storeStockDao()
    private val vehicleStockDao = db.vehicleStockDao()
    private val transactionDao = db.transactionDao()

    val products: Flow<List<Product>> = productDao.getAll()
    val vehicles: Flow<List<Vehicle>> = vehicleDao.getAll()
    val storeStock: Flow<List<StoreStock>> = storeStockDao.getAll()
    val vehicleStock: Flow<List<VehicleStock>> = vehicleStockDao.getAll()
    val transactions: Flow<List<TransactionEntity>> = transactionDao.getAll()

    /** Populates 17 products + 6 vehicles the first time the app runs. */
    suspend fun seedIfEmpty() = db.withTransaction {
        if (productDao.count() == 0) {
            productDao.insertAll(SeedData.productNames.map { Product(name = it) })
        }
        if (vehicleDao.count() == 0) {
            vehicleDao.insertAll(SeedData.vehicleNames.map { Vehicle(name = it) })
        }
        // Make sure every product has a store_stock row (starts at 0/0).
        productDao.getAllIds().forEach { storeStockDao.ensureRow(it) }
    }

    /** Purchase: full stock arrives and is added to the store. */
    suspend fun recordPurchase(productId: Long, fullQty: Int, notes: String = "") = db.withTransaction {
        storeStockDao.ensureRow(productId)
        storeStockDao.adjust(productId, deltaFull = fullQty, deltaEmpty = 0)
        transactionDao.insert(
            TransactionEntity(type = TransactionType.PURCHASE, productId = productId, fullQty = fullQty, notes = notes)
        )
    }

    /** Dispatch: full stock moves from the store onto a vehicle for delivery. */
    suspend fun recordDispatch(productId: Long, vehicleId: Long, fullQty: Int, notes: String = "") =
        db.withTransaction {
            storeStockDao.ensureRow(productId)
            vehicleStockDao.ensureRow(vehicleId, productId)
            storeStockDao.adjust(productId, deltaFull = -fullQty, deltaEmpty = 0)
            vehicleStockDao.adjust(vehicleId, productId, deltaFull = fullQty, deltaEmpty = 0)
            transactionDao.insert(
                TransactionEntity(
                    type = TransactionType.DISPATCH,
                    productId = productId,
                    vehicleId = vehicleId,
                    fullQty = fullQty,
                    notes = notes
                )
            )
        }

    /**
     * Vehicle return: the vehicle comes back from its run with empties collected
     * from customers, and possibly some full units that didn't get delivered.
     * Both move from the vehicle's load back into the store's stock.
     */
    suspend fun recordVehicleReturn(
        productId: Long,
        vehicleId: Long,
        returnedEmptyQty: Int,
        unsoldFullQty: Int = 0,
        notes: String = ""
    ) = db.withTransaction {
        storeStockDao.ensureRow(productId)
        vehicleStockDao.ensureRow(vehicleId, productId)
        vehicleStockDao.adjust(vehicleId, productId, deltaFull = -unsoldFullQty, deltaEmpty = -returnedEmptyQty)
        storeStockDao.adjust(productId, deltaFull = unsoldFullQty, deltaEmpty = returnedEmptyQty)
        transactionDao.insert(
            TransactionEntity(
                type = TransactionType.RETURN,
                productId = productId,
                vehicleId = vehicleId,
                fullQty = unsoldFullQty,
                emptyQty = returnedEmptyQty,
                notes = notes
            )
        )
    }

    fun transactionsByType(type: TransactionType): Flow<List<TransactionEntity>> = transactionDao.getByType(type)

    fun transactionsBetween(start: Long, end: Long): Flow<List<TransactionEntity>> =
        transactionDao.getBetween(start, end)

    suspend fun renameProduct(id: Long, name: String) = productDao.rename(id, name)

    suspend fun renameVehicle(id: Long, name: String) = vehicleDao.rename(id, name)
}
