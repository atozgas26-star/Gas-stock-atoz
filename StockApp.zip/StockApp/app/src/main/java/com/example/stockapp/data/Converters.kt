package com.example.stockapp.data

import androidx.room.TypeConverter
import com.example.stockapp.data.entities.TransactionType

class Converters {
    @TypeConverter
    fun fromType(value: TransactionType): String = value.name

    @TypeConverter
    fun toType(value: String): TransactionType = TransactionType.valueOf(value)
}
