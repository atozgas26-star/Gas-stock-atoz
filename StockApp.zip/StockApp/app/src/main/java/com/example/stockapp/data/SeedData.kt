package com.example.stockapp.data

/**
 * Initial data loaded the first time the app runs (empty database).
 * Rename these to your real product / vehicle names — they're placeholders
 * so the app has exactly 17 products and 6 vehicles to start with, matching
 * the requested scope. Renaming later (via the DB) never breaks stock rows,
 * since they're keyed by id, not by name.
 */
object SeedData {
    val productNames: List<String> = (1..17).map { "Product $it" }

    val vehicleNames: List<String> = (1..6).map { "Vehicle $it" }
}
