package com.example.stockapp.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.stockapp.data.entities.Product
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY id ASC")
    fun getAll(): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(products: List<Product>)

    @Insert
    suspend fun insert(product: Product): Long

    @Query("SELECT COUNT(*) FROM products")
    suspend fun count(): Int

    @Query("SELECT id FROM products")
    suspend fun getAllIds(): List<Long>

    @Query("UPDATE products SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)
}
