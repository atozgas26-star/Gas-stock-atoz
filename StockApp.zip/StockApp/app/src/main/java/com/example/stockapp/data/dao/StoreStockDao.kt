package com.example.stockapp.data.dao

import androidx.room.Dao
import androidx.room.Query
import com.example.stockapp.data.entities.StoreStock
import kotlinx.coroutines.flow.Flow

@Dao
interface StoreStockDao {
    @Query("SELECT * FROM store_stock")
    fun getAll(): Flow<List<StoreStock>>

    @Query("SELECT * FROM store_stock WHERE productId = :productId")
    suspend fun getForProduct(productId: Long): StoreStock?

    @Query("INSERT OR IGNORE INTO store_stock (productId, fullQty, emptyQty) VALUES (:productId, 0, 0)")
    suspend fun ensureRow(productId: Long)

    @Query(
        "UPDATE store_stock SET fullQty = fullQty + :deltaFull, emptyQty = emptyQty + :deltaEmpty " +
            "WHERE productId = :productId"
    )
    suspend fun adjust(productId: Long, deltaFull: Int, deltaEmpty: Int)
}
