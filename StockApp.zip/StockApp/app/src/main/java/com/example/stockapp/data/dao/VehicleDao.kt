package com.example.stockapp.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.stockapp.data.entities.Vehicle
import kotlinx.coroutines.flow.Flow

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles ORDER BY name ASC")
    fun getAll(): Flow<List<Vehicle>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(vehicles: List<Vehicle>)

    @Insert
    suspend fun insert(vehicle: Vehicle): Long

    @Query("SELECT COUNT(*) FROM vehicles")
    suspend fun count(): Int
}
