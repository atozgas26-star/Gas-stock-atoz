package com.example.stockapp.data.dao

import androidx.room.Dao
import androidx.room.Query
import com.example.stockapp.data.entities.VehicleStock
import kotlinx.coroutines.flow.Flow

@Dao
interface VehicleStockDao {
    @Query("SELECT * FROM vehicle_stock")
    fun getAll(): Flow<List<VehicleStock>>

    @Query("SELECT * FROM vehicle_stock WHERE vehicleId = :vehicleId")
    fun getForVehicle(vehicleId: Long): Flow<List<VehicleStock>>

    @Query("SELECT * FROM vehicle_stock WHERE vehicleId = :vehicleId AND productId = :productId")
    suspend fun get(vehicleId: Long, productId: Long): VehicleStock?

    @Query(
        "INSERT OR IGNORE INTO vehicle_stock (vehicleId, productId, fullQty, emptyQty) " +
            "VALUES (:vehicleId, :productId, 0, 0)"
    )
    suspend fun ensureRow(vehicleId: Long, productId: Long)

    @Query(
        "UPDATE vehicle_stock SET fullQty = fullQty + :deltaFull, emptyQty = emptyQty + :deltaEmpty " +
            "WHERE vehicleId = :vehicleId AND productId = :productId"
    )
    suspend fun adjust(vehicleId: Long, productId: Long, deltaFull: Int, deltaEmpty: Int)
}
