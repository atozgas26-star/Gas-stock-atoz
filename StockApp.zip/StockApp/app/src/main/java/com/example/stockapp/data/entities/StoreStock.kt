package com.example.stockapp.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per product, tracking how many FULL units and how many EMPTY
 * units are currently sitting in the store (not out on a vehicle).
 */
@Entity(tableName = "store_stock")
data class StoreStock(
    @PrimaryKey val productId: Long,
    val fullQty: Int = 0,
    val emptyQty: Int = 0
)
