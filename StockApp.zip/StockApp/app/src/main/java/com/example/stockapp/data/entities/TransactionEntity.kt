package com.example.stockapp.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType { PURCHASE, DISPATCH, RETURN }

/**
 * Immutable log of every stock-moving event. This is what powers the
 * Reports screen and is never edited after insert, only appended to.
 */
@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: TransactionType,
    val productId: Long,
    val vehicleId: Long? = null,
    val fullQty: Int = 0,
    val emptyQty: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)
