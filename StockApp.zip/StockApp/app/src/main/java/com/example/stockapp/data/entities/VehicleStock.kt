package com.example.stockapp.data.entities

import androidx.room.Entity

/**
 * One row per (vehicle, product) pair, tracking how many FULL units and how
 * many EMPTY units are currently loaded on that vehicle (out on delivery).
 */
@Entity(tableName = "vehicle_stock", primaryKeys = ["vehicleId", "productId"])
data class VehicleStock(
    val vehicleId: Long,
    val productId: Long,
    val fullQty: Int = 0,
    val emptyQty: Int = 0
)
