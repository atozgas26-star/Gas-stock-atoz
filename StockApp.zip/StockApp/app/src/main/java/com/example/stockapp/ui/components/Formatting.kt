package com.example.stockapp.ui.components

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val formatter = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())

fun formatTimestamp(millis: Long): String = formatter.format(Date(millis))
