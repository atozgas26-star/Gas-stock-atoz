package com.example.stockapp.ui.navigation

sealed class Screen(val route: String, val label: String) {
    object Home : Screen("home", "Home")
    object StoreStock : Screen("store_stock", "Store Full / Empty")
    object Purchase : Screen("purchase", "Purchase")
    object Dispatch : Screen("dispatch", "Dispatch")
    object VehicleReturn : Screen("vehicle_return", "Vehicle Return")
    object CurrentStock : Screen("current_stock", "Current Stock")
    object Reports : Screen("reports", "Reports")
    object Manage : Screen("manage", "Manage Products & Vehicles")
}
