package com.example.stockapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.stockapp.data.entities.Product
import com.example.stockapp.data.entities.Vehicle
import com.example.stockapp.ui.components.ScreenScaffold
import com.example.stockapp.viewmodel.AppViewModel

@Composable
fun CurrentStockScreen(navController: NavController, viewModel: AppViewModel) {
    val products by viewModel.products.collectAsState()
    val vehicles by viewModel.vehicles.collectAsState()
    val storeStock by viewModel.storeStock.collectAsState()
    val vehicleStock by viewModel.vehicleStock.collectAsState()

    // Tab 0 = Store, tabs 1..n = each vehicle.
    var selectedTab by remember { mutableIntStateOf(0) }
    val productById = remember(products) { products.associateBy { it.id } }

    ScreenScaffold(title = "Current Stock", navController = navController) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Store") }
                )
                vehicles.forEachIndexed { index, vehicle ->
                    Tab(
                        selected = selectedTab == index + 1,
                        onClick = { selectedTab = index + 1 },
                        text = { Text(vehicle.name) }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text("Product", modifier = Modifier.weight(2f), fontWeight = FontWeight.Bold)
                Text("Full", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text("Empty", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
            }

            LazyColumn(
                contentPadding = PaddingValues(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (selectedTab == 0) {
                    val stockByProduct = storeStock.associateBy { it.productId }
                    items(products) { product ->
                        val stock = stockByProduct[product.id]
                        StockRow(product.name, stock?.fullQty ?: 0, stock?.emptyQty ?: 0)
                    }
                } else {
                    val vehicle: Vehicle = vehicles[selectedTab - 1]
                    val rows = vehicleStock.filter { it.vehicleId == vehicle.id && it.productId in productById }
                    if (rows.isEmpty()) {
                        item {
                            Text(
                                "Nothing currently loaded on ${vehicle.name}.",
                                modifier = Modifier.padding(16.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    items(rows) { row ->
                        val name = productById[row.productId]?.name ?: "Unknown"
                        StockRow(name, row.fullQty, row.emptyQty)
                    }
                }
            }
        }
    }
}

@Composable
private fun StockRow(name: String, full: Int, empty: Int) {
    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Row(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
            Text(name, modifier = Modifier.weight(2f))
            Text("$full", modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.primary)
            Text("$empty", modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.tertiary)
        }
    }
}
