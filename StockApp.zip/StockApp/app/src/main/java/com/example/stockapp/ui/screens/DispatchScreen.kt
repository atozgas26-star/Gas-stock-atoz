package com.example.stockapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.stockapp.data.entities.Product
import com.example.stockapp.data.entities.Vehicle
import com.example.stockapp.ui.components.DropdownSelector
import com.example.stockapp.ui.components.ScreenScaffold
import com.example.stockapp.viewmodel.AppViewModel

@Composable
fun DispatchScreen(navController: NavController, viewModel: AppViewModel) {
    val products by viewModel.products.collectAsState()
    val vehicles by viewModel.vehicles.collectAsState()
    val storeStock by viewModel.storeStock.collectAsState()

    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var selectedVehicle by remember { mutableStateOf<Vehicle?>(null) }
    var qtyText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    val availableFull = selectedProduct?.let { p ->
        storeStock.firstOrNull { it.productId == p.id }?.fullQty ?: 0
    }

    ScreenScaffold(title = "Dispatch (To Vehicle)", navController = navController) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DropdownSelector(
                label = "Product",
                items = products,
                selected = selectedProduct,
                itemLabel = { it.name },
                onSelect = { selectedProduct = it }
            )
            if (selectedProduct != null) {
                Text(
                    "Available in store: $availableFull full",
                    color = MaterialTheme.colorScheme.primary
                )
            }
            DropdownSelector(
                label = "Vehicle",
                items = vehicles,
                selected = selectedVehicle,
                itemLabel = { it.name },
                onSelect = { selectedVehicle = it }
            )
            OutlinedTextField(
                value = qtyText,
                onValueChange = { qtyText = it.filter { c -> c.isDigit() } },
                label = { Text("Quantity to dispatch (Full)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (optional)") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    val product = selectedProduct
                    val vehicle = selectedVehicle
                    val qty = qtyText.toIntOrNull()
                    when {
                        product == null || vehicle == null || qty == null || qty <= 0 ->
                            message = "Select a product, a vehicle, and a valid quantity."
                        availableFull != null && qty > availableFull ->
                            message = "Only $availableFull full units available in store."
                        else -> {
                            viewModel.dispatch(product.id, vehicle.id, qty, notes)
                            message = "Dispatched $qty x ${product.name} on ${vehicle.name}"
                            qtyText = ""
                            notes = ""
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Record Dispatch")
            }
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        }
    }
}
