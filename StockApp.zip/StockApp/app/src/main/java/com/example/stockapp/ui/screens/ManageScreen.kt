package com.example.stockapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.stockapp.ui.components.ScreenScaffold
import com.example.stockapp.viewmodel.AppViewModel

@Composable
fun ManageScreen(navController: NavController, viewModel: AppViewModel) {
    val products by viewModel.products.collectAsState()
    val vehicles by viewModel.vehicles.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }

    ScreenScaffold(title = "Manage Products & Vehicles", navController = navController) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Products") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Vehicles") })
            }
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (selectedTab == 0) {
                    items(products, key = { it.id }) { product ->
                        RenameRow(
                            initialName = product.name,
                            onSave = { newName -> viewModel.renameProduct(product.id, newName) }
                        )
                    }
                } else {
                    items(vehicles, key = { it.id }) { vehicle ->
                        RenameRow(
                            initialName = vehicle.name,
                            onSave = { newName -> viewModel.renameVehicle(vehicle.id, newName) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RenameRow(initialName: String, onSave: (String) -> Unit) {
    var text by remember(initialName) { mutableStateOf(initialName) }

    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            IconButton(
                onClick = { onSave(text) },
                enabled = text.isNotBlank() && text != initialName
            ) {
                Icon(Icons.Default.Check, contentDescription = "Save")
            }
        }
    }
}
