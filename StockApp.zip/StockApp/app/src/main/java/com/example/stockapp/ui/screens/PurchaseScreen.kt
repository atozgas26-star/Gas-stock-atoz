package com.example.stockapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.stockapp.data.entities.Product
import com.example.stockapp.ui.components.DropdownSelector
import com.example.stockapp.ui.components.ScreenScaffold
import com.example.stockapp.viewmodel.AppViewModel

@Composable
fun PurchaseScreen(navController: NavController, viewModel: AppViewModel) {
    val products by viewModel.products.collectAsState()
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var qtyText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    ScreenScaffold(title = "Purchase (Full Stock In)", navController = navController) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DropdownSelector(
                label = "Product",
                items = products,
                selected = selectedProduct,
                itemLabel = { it.name },
                onSelect = { selectedProduct = it }
            )
            OutlinedTextField(
                value = qtyText,
                onValueChange = { qtyText = it.filter { c -> c.isDigit() } },
                label = { Text("Quantity (Full units)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (optional, e.g. supplier)") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    val product = selectedProduct
                    val qty = qtyText.toIntOrNull()
                    if (product != null && qty != null && qty > 0) {
                        viewModel.purchase(product.id, qty, notes)
                        message = "Purchase recorded: $qty x ${product.name}"
                        qtyText = ""
                        notes = ""
                    } else {
                        message = "Select a product and enter a valid quantity."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Record Purchase")
            }
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        }
    }
}
