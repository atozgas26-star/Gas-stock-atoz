package com.example.stockapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.stockapp.data.entities.TransactionEntity
import com.example.stockapp.data.entities.TransactionType
import com.example.stockapp.ui.components.ScreenScaffold
import com.example.stockapp.ui.components.formatTimestamp
import com.example.stockapp.viewmodel.AppViewModel

@Composable
fun ReportsScreen(navController: NavController, viewModel: AppViewModel) {
    val transactions by viewModel.transactions.collectAsState()
    val products by viewModel.products.collectAsState()
    val vehicles by viewModel.vehicles.collectAsState()
    val productById = remember(products) { products.associateBy { it.id } }
    val vehicleById = remember(vehicles) { vehicles.associateBy { it.id } }

    var filter by remember { mutableStateOf<TransactionType?>(null) }
    val filtered = remember(transactions, filter) {
        if (filter == null) transactions else transactions.filter { it.type == filter }
    }

    val totalFullPurchased = transactions.filter { it.type == TransactionType.PURCHASE }.sumOf { it.fullQty }
    val totalFullDispatched = transactions.filter { it.type == TransactionType.DISPATCH }.sumOf { it.fullQty }
    val totalEmptyReturned = transactions.filter { it.type == TransactionType.RETURN }.sumOf { it.emptyQty }

    ScreenScaffold(title = "Reports", navController = navController) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            Card(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Summary", fontWeight = FontWeight.Bold)
                    Text("Total purchased (full): $totalFullPurchased")
                    Text("Total dispatched (full): $totalFullDispatched")
                    Text("Total empties returned: $totalEmptyReturned")
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("All") })
                FilterChip(
                    selected = filter == TransactionType.PURCHASE,
                    onClick = { filter = TransactionType.PURCHASE },
                    label = { Text("Purchase") }
                )
                FilterChip(
                    selected = filter == TransactionType.DISPATCH,
                    onClick = { filter = TransactionType.DISPATCH },
                    label = { Text("Dispatch") }
                )
                FilterChip(
                    selected = filter == TransactionType.RETURN,
                    onClick = { filter = TransactionType.RETURN },
                    label = { Text("Return") }
                )
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered) { tx ->
                    TransactionRow(
                        tx = tx,
                        productName = productById[tx.productId]?.name ?: "Unknown product",
                        vehicleName = tx.vehicleId?.let { vehicleById[it]?.name }
                    )
                }
            }
        }
    }
}

@Composable
private fun TransactionRow(tx: TransactionEntity, productName: String, vehicleName: String?) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(tx.type.name, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(formatTimestamp(tx.timestamp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(productName)
            vehicleName?.let { Text("Vehicle: $it") }
            Row {
                if (tx.fullQty != 0) Text("Full: ${tx.fullQty}  ")
                if (tx.emptyQty != 0) Text("Empty: ${tx.emptyQty}")
            }
            if (tx.notes.isNotBlank()) {
                Text(tx.notes, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
