package com.example.stockapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.stockapp.data.entities.Product
import com.example.stockapp.data.entities.StoreStock
import com.example.stockapp.ui.components.ScreenScaffold
import com.example.stockapp.viewmodel.AppViewModel

@Composable
fun StoreStockScreen(navController: NavController, viewModel: AppViewModel) {
    val products by viewModel.products.collectAsState()
    val storeStock by viewModel.storeStock.collectAsState()
    val stockByProduct = storeStock.associateBy { it.productId }

    ScreenScaffold(title = "Store Full / Empty", navController = navController) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text("Product", modifier = Modifier.weight(2f), fontWeight = FontWeight.Bold)
                Text("Full", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text("Empty", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
            }
            HorizontalDivider()
            LazyColumn(
                contentPadding = PaddingValues(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(products) { product ->
                    StoreStockRow(product, stockByProduct[product.id])
                }
            }
        }
    }
}

@Composable
private fun StoreStockRow(product: Product, stock: StoreStock?) {
    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Text(product.name, modifier = Modifier.weight(2f))
            Text(
                "${stock?.fullQty ?: 0}",
                modifier = Modifier.weight(1f),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "${stock?.emptyQty ?: 0}",
                modifier = Modifier.weight(1f),
                color = MaterialTheme.colorScheme.tertiary
            )
        }
    }
}
