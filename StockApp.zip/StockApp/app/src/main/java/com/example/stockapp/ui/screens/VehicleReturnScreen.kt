package com.example.stockapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.stockapp.data.entities.Product
import com.example.stockapp.data.entities.Vehicle
import com.example.stockapp.ui.components.DropdownSelector
import com.example.stockapp.ui.components.ScreenScaffold
import com.example.stockapp.viewmodel.AppViewModel

@Composable
fun VehicleReturnScreen(navController: NavController, viewModel: AppViewModel) {
    val products by viewModel.products.collectAsState()
    val vehicles by viewModel.vehicles.collectAsState()
    val vehicleStock by viewModel.vehicleStock.collectAsState()

    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var selectedVehicle by remember { mutableStateOf<Vehicle?>(null) }
    var emptyQtyText by remember { mutableStateOf("") }
    var unsoldFullQtyText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    val loaded = if (selectedProduct != null && selectedVehicle != null) {
        vehicleStock.firstOrNull { it.productId == selectedProduct!!.id && it.vehicleId == selectedVehicle!!.id }
    } else null

    ScreenScaffold(title = "Vehicle Return", navController = navController) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DropdownSelector(
                label = "Vehicle",
                items = vehicles,
                selected = selectedVehicle,
                itemLabel = { it.name },
                onSelect = { selectedVehicle = it }
            )
            DropdownSelector(
                label = "Product",
                items = products,
                selected = selectedProduct,
                itemLabel = { it.name },
                onSelect = { selectedProduct = it }
            )
            if (loaded != null) {
                Text(
                    "Currently on vehicle: ${loaded.fullQty} full, ${loaded.emptyQty} empty",
                    color = MaterialTheme.colorScheme.primary
                )
            }
            OutlinedTextField(
                value = emptyQtyText,
                onValueChange = { emptyQtyText = it.filter { c -> c.isDigit() } },
                label = { Text("Empties collected from customers") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = unsoldFullQtyText,
                onValueChange = { unsoldFullQtyText = it.filter { c -> c.isDigit() } },
                label = { Text("Unsold full units returning (optional)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (optional)") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    val product = selectedProduct
                    val vehicle = selectedVehicle
                    val emptyQty = emptyQtyText.toIntOrNull() ?: 0
                    val unsoldFull = unsoldFullQtyText.toIntOrNull() ?: 0
                    when {
                        product == null || vehicle == null ->
                            message = "Select a vehicle and a product."
                        emptyQty <= 0 && unsoldFull <= 0 ->
                            message = "Enter at least one quantity (empties or unsold full)."
                        else -> {
                            viewModel.vehicleReturn(product.id, vehicle.id, emptyQty, unsoldFull, notes)
                            message = "Return recorded for ${product.name} from ${vehicle.name}"
                            emptyQtyText = ""
                            unsoldFullQtyText = ""
                            notes = ""
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Record Vehicle Return")
            }
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        }
    }
}
