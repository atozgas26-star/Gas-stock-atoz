package com.example.stockapp.ui.theme

import androidx.compose.ui.graphics.Color

val Blue80 = Color(0xFFAAC7FF)
val BlueGrey80 = Color(0xFFC0C9DD)
val Teal80 = Color(0xFFA0D9D0)

val Blue40 = Color(0xFF2E5FA3)
val BlueGrey40 = Color(0xFF4C5B71)
val Teal40 = Color(0xFF3A7A70)
