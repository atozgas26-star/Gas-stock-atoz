package com.example.stockapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.stockapp.data.AppRepository
import com.example.stockapp.data.entities.Product
import com.example.stockapp.data.entities.StoreStock
import com.example.stockapp.data.entities.TransactionEntity
import com.example.stockapp.data.entities.Vehicle
import com.example.stockapp.data.entities.VehicleStock
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(private val repository: AppRepository) : ViewModel() {

    val products: StateFlow<List<Product>> = repository.products
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vehicles: StateFlow<List<Vehicle>> = repository.vehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val storeStock: StateFlow<List<StoreStock>> = repository.storeStock
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vehicleStock: StateFlow<List<VehicleStock>> = repository.vehicleStock
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<TransactionEntity>> = repository.transactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun purchase(productId: Long, fullQty: Int, notes: String = "") {
        viewModelScope.launch { repository.recordPurchase(productId, fullQty, notes) }
    }

    fun dispatch(productId: Long, vehicleId: Long, fullQty: Int, notes: String = "") {
        viewModelScope.launch { repository.recordDispatch(productId, vehicleId, fullQty, notes) }
    }

    fun vehicleReturn(
        productId: Long,
        vehicleId: Long,
        returnedEmptyQty: Int,
        unsoldFullQty: Int,
        notes: String = ""
    ) {
        viewModelScope.launch {
            repository.recordVehicleReturn(productId, vehicleId, returnedEmptyQty, unsoldFullQty, notes)
        }
    }
}
